package tree;

import java.util.*;

public class MyTree {

	
	public static String createTree() {
		
		String[] uinput = { 
				"Car.Sedan.Color.Red",
				"Car.Sedan.Color.Blue",
				"Car.Sedan.Model.Color.Red",
				"Car.Sedan.Model.Color.Blue",		
				"Car.SUV.Color",
				"Car.Hatchback.Color",
				"Car.Hatchback.Model"
			};
			
			Node root = null;
			
			for(int i = 0; i < uinput.length; i++) {
			
				String tmp[] = uinput[i].split("[.]");
				
				if(root == null) {
					root = new Node(tmp[0]);
				}
				
				Node current = root;
				
				for(int j = 1; j < tmp.length; j++) {
					if(current.getChildByLabel(tmp[j]) == null) {
						Node child = new Node(tmp[j]);
						current.addChild(child);
						current = child;
					}
					else {
						current = current.getChildByLabel(tmp[j]);
					}
				}
				
			}     

        return getJson(root);
        
	}
	
	public static String getJson(Node current) {
		String res = "{ \"text\": { \"name\": \"" + current.label + "\" }";
		
		if(current.getChildList().size() > 0) {
			res += ", \"children\": [";
			
			for(int i = 0; i < current.childList.size(); i++) {
				res += getJson(current.childList.get(i));
				if(i != current.childList.size() - 1) {
					res += ",";
				}
			}
			
			res += "]";
		}
		
		res += "}";
		return res;
	}
	
	
}

